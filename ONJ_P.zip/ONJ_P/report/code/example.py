import os
import time
import random
import numpy as np

fruits = np.array(["apple", "banana", "cherry"])
for x in fruits:
  print(x)
